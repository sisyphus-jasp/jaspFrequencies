Extract reproduction.jasp and open it in JASP.
The file includes the synthetic data, analysis settings and saved results.
Recompute the analysis to check the module version installed in your JASP.
